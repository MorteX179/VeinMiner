using Vintagestory.API.Common;

public class VeinMinerConfig
{
    public int MaxBlocks = 4;
}
